const Discord = require('discord.js');
const disbut = require('discord-buttons');
const { MessageActionRow, MessageButton } = require("discord-buttons");

module.exports = {
  name: "help",
   aliases: ["help"],
  run: async (client, message, args ) => {
      //--------------------------------------S T A R T---------------------------------------

    //--------------------EMBEDS------------------------

    const embed = new Discord.MessageEmbed()

  .setDescription(" **[Help Menu](https://discord.gg/PYWyxNRTHv)** \n \n <a:hello:916838502941999234>Hi this all the commands listed and available. \n <a:YellowArrow:915157387013406781> Click the buttons below to view category! \n <a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022> \n <a:hmm:916833870048034817>`Admin` \n <a:hmm:916833870048034817>`Automod`\n   <a:hmm:916833870048034817>`Economy` \n  <a:hmm:916833870048034817>`Fun` \n  <a:hmm:916833870048034817>`Games` \n  <a:hmm:916833870048034817>`Image` \n <a:hmm:916833870048034817>`Moderation`\n <a:hmm:916833870048034817>`Utility` \n <a:hmm:916833870048034817> `ticket` \n <a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022><a:idkk:916837557340373022> \n **Made by** [**Banad#0001**](https://discord.gg/PYWyxNRTHv)<a:smoking:917850362591985705>")

  
    
    .setThumbnail(client.user.displayAvatarURL())
    .setColor("YELLOW");

    const embed1 = new Discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle("<a:left:916850028004397056>Admin, Moderation/automod<a:right:916850010686128189>")
        .addField("ㅤ⠀⠀⠀ \n  <:admin:917009135332102205>**Admin**",
          "<:rightb:917013031920218113>`react` `snipe`<:leftb:917013018129354772> \n\n<:mod:917010148864704572>**Moderation** \n <:rightb:917013031920218113>`addrole` `ban` `purge` `hackban` `kick` `lock` `mute` `removerole` `slowmode` `timedlockdown` `unlock` `unmute`<:leftb:917013018129354772> \n\n<:auto:917013665507582002>**AutoModeration**  \n <:rightb:917013031920218113>`anti-alt` `autorole` `role-all`<:leftb:917013018129354772>"
        )
      
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter(message.client.user.username, message.client.user.avatarURL())

    const embed2 = new Discord.MessageEmbed()
    .setColor("RANDOM")
     .setTitle('<a:left:916850028004397056> Info & help & economy <a:right:916850010686128189>')
      .addField("⠀⠀⠀ \n <a:info:917035868869513296>**Info** ",
        "<:rightb:917013031920218113>`badges` `botinfo` `roleinfo` `servericon` `serverinfo` `userinfo` `invite` `uptime` `avatar` `rank`<:leftb:917013018129354772> \n\n <a:version:915157386925326380>**Help**\n <:rightb:917013031920218113>`bug` `help` `invite`<:leftb:917013018129354772>\n\n <:ECONOMY:917035198036713472>**ECONOMY**  \n  <:rightb:917013031920218113>`balance` `buy` `daily` `deposit` `give` `inventory` `leaderboard` `rob` `shop` `use` `weekly` `withdraw` `work`<:leftb:917013018129354772>"
        )
        
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter(message.client.user.username, message.client.user.avatarURL())

    const embed3 = new Discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle('<a:left:916850028004397056>Fun & Images <a:right:916850010686128189>')
      .addField("ㅤ⠀⠀⠀ \n <a:fun:917038789518573619> **Fun**","<:rightb:917013031920218113>`ascii` `coinflip` `drake` `emojify` `joke` `meme` `rps` `slap` `trumptweet` `idp`<:leftb:917013018129354772>\n\n <a:image:917040021318549504>**Image**\n <:rightb:917013031920218113>`achievement` `captcha` `hug` `gay` `meeting` `rip` `tweet` `300yr`<:leftb:917013018129354772>",)
      
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter(message.client.user.username, message.client.user.avatarURL())

    const embed4 = new Discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle(` <a:left:916850028004397056>Ticket &Owner<a:right:916850010686128189> `)
      .addField(":tickets: `*Ticket*`\n <:rightb:917013031920218113> `send ` `add` `close` `delete` `remove` `open` `rename` `setchannels ` `setstaff`<:leftb:917013018129354772> ⠀⠀⠀ \n <a:ownerd:917046005604696104>**Owner**"," \n <:rightb:917013031920218113>`eval` `leaveserver` `serverlist` `status`<:leftb:917013018129354772>\n\n<a:music:917054400009211964>**MUSIC**\n <:rightb:917013031920218113>`play` `stop` `skip` `skipto` `pause` `shuffle` `prunning` `loop` `uptime` `ping` `playlist` `move` `queue` `remove` `volume <1-100>`<:leftb:917013018129354772> \n\n<a:http:917058031211118593>**UTILITY** \n <:rightb:917013031920218113>`vote` `advice` `findemoji` `membercount` `announce`<:leftb:917013018129354772> \n\n <:game:917055621205987439>**GAMES** \n <:rightb:917013031920218113>`8ball`<:leftb:917013018129354772>" //bro here 
        )
      
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter(message.client.user.username, message.client.user.avatarURL())
      
      

    //--------------------EMBEDS------------------------

    //--------------------Buttons------------------------

    let button1 = new MessageButton()
    .setLabel(`Admin , Auto/Moderation`)
    .setID(`help1`)
    .setEmoji(`917009135332102205`)
    .setStyle("red");

    let button2 = new MessageButton()
    .setLabel(`Info, Help & Economy`)
    .setID(`help2`)
    .setEmoji(`908687982666608640`)
    .setStyle("red");

    let button3 = new MessageButton()
    .setLabel(`Fun & Images`)
    .setID(`help3`)
    .setEmoji(`917038789518573619`)
    .setStyle("red");

    let button4 = new MessageButton()
    .setLabel(` Ticket, Owner, UTILITY, Games & Music`)
    .setID(`help4`)
    .setEmoji(`917046005604696104`)
    .setStyle("red");

    let button5 = new disbut.MessageButton()
    .setStyle('url')
    .setLabel('Vote')
    .setEmoji('915164734175739925')
    .setURL(`https://discordbotlist.com/bots/banad`);

    let row = new MessageActionRow()
    .addComponents(button1, button2, button3, button4, button5);

    //--------------------Buttons------------------------

    const MESSAGE = await message.channel.send(embed, row);

    const filter = ( button ) => button.clicker.user.id === message.author.id 
    const collector = MESSAGE.createButtonCollector(filter, { time : 120000 });

    collector.on('collect', async (b) => {

        if(b.id == "help1") {

            MESSAGE.edit(embed1, row);
            await b.reply.defer()

        }

        if(b.id == "help2") {
            
            MESSAGE.edit(embed2, row);
            await b.reply.defer()

        }

        if(b.id == "help3") {
            
            MESSAGE.edit(embed3, row);
            await b.reply.defer()

        }

        if(b.id == "help4") {
            
            MESSAGE.edit(embed4, row);
            await b.reply.defer()

        if(b.id == "help5") {
          
        }

        }


    })

    collector.on('end', (b) => {
        MESSAGE.edit(" `This help menu is expired! Type the command again to view.` ")
    })

    }
  };